std::vector<int> Annealing::algorithm() {
	int worse_solution_counter = 0;
	int worse_acceptable = worse_acceptable_factor * vertex_number;
	double temperature = begin_temperature;
	std::vector<int> current_solution = randomSolution(vertex_number);
	std::vector<int> best_solution = current_solution;
	std::vector<int> adjacent_solution = current_solution;
	int cost_current_solution, cost_best_solution, cost_adjacent_solution;
	cost_current_solution = calcCost(current_solution);
	cost_best_solution = cost_current_solution;

	while (worse_solution_counter < worse_acceptable) {
		adjacent_solution = adjacentSolution(current_solution);
		cost_adjacent_solution = calcCost(adjacent_solution);

		if (cost_adjacent_solution < cost_best_solution) {
			best_solution = adjacent_solution;
			cost_best_solution = cost_adjacent_solution;
		}

		if (cost_adjacent_solution < cost_current_solution) {
			current_solution = adjacent_solution;
			cost_current_solution = cost_adjacent_solution;
			worse_solution_counter = 0;
		} else {
			++worse_solution_counter;
			double delta = cost_adjacent_solution - cost_current_solution;
			double x = (rand() % 100000) / 100000.0;
			if (x < (exp((-delta) / temperature))) {
				current_solution = adjacent_solution;
				cost_current_solution = cost_adjacent_solution;
			}
		}
		temperature *= temperature_change_factor;
	}
	return best_solution;
}