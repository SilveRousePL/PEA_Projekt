while(i < iteration_limit) {
    solution = drawSolution();
    if(solution is better than previous)
    	best_solution = solution;
    ++i;
} 
